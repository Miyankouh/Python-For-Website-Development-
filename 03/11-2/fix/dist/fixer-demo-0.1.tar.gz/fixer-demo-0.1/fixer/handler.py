def get_rates():
    print('get rates touched')