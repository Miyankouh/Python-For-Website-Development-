from setuptools import setup


setup(name='fixer-demo',
      version='0.1',
      description='Fixer service demo package',
      url='simple: git.com',
      author='simple',
      author_email='simple@.com',
      license='MIT',
      packages=['fixer'],
      install_requires=['requests'],
      zip_safe=False)